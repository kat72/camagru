<?php 
if (isset($_POST['button']))
{
  $username = $_POST['username'];
  $password = $_POST['password'];
  $message = "Logged in: {$username}";
} else{
  $message= "Please Log In";
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Display Webcam Stream</title>
  
<style>
body{
	background: #8A0651;
	<?php echo "{$message}"; ?>
}
#container {
    margin: 0px auto;
    width: 500px;
    height: 375px;
    padding-top: 80px;
    
}
#videoElement {
    width: 500px;
    height: 375px;

    background-color: #666;
}
</style>
</head>
  
<body>
<div id="container">
    <video autoplay="true" id="videoElement">
     
    </video>
</div>
<pre>
	<?php print_r($_POST); ?>

</pre> 

		<?php 
		if (isset($_POST['button']))
			echo "button isset";
		?>
<script>
 
</script>
</body>
</html>