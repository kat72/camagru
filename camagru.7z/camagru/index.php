<?php 
/*require_once 'core/init.php';

$user = DB::getInstance()->query("Select  FROM users");
if ($user->error()){
  echo 'user does not exist';
}
else{
  echo 'I am alive';
}
if (isset($_POST['button']))
{
  $username = $_POST['username'];
  $password = $_POST['password'];m
  $message = "Loggin in: {$username}";
} else{
  $message = "Please Log In";
}*/
?>
<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>Flat HTML5/CSS3 Login Form</title>  
      <link rel="stylesheet" href="css/style.css">
</head>

<body>
  <div class="login-page">
  <h1>CAMAGRU</h1>
  <?php #echo #$message; 
  ?>
  <div class="form">
    <form action="webcam.php" method="post" class="login-form">
      <input type="text" name="username" placeholder="username"/>
      <input type="password" name="password" placeholder="password"/>
      <button type="submit" name="button">login</button>
      <p class="message">Not registered? <a href="register.php">Create an account</a></p>
    </form>
  </div>
</div>
  </body>
</html>
?>
