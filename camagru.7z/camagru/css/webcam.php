<?php
	echo "hello world";
?>